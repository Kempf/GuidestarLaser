mdraw.zip    drawing program that can output PostScript

Mayura Draw is a PostScript based vector drawing program for Windows. It
lets you draw graphical shapes such as rectangles, ellipses, bezier curves,
polygons and text. Graphical objects can be edited, or transformed, i.e.,
moved, scaled, rotated, skewed or reflected. All objects, including text,
are editable even after transformation. Mayura Draw outputs custom PostScript
for best quality output on printers that support PostScript. Non-PostScript
printers are also supported. Drawings can be saved in EPS format for easy 
inclusion in word processor documents.

Mayura Draw is shareware. Shareware registration fee is $39.
To register online visit http://www.mayura.com/register.htm

System requirements:
  Hardware
    - Windows compatible PC
    - PostScript printer recommended.
  Software
    - Windows 98, Me, NT 4.0, Windows 2000, Windows XP, Windows 7 or later.
