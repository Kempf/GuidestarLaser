%!PS-Adobe-3.0 EPSF-3.0
%%Creator: PageDraw, Version 2.0
%%Title: diagram.pdx
%%CreationDate: Sun Feb 11 01:10:53 1996
%%BoundingBox: 23 11 586 781
%%DocumentFonts: ArialMT
%%Orientation: Landscape
%%EndComments
%%BeginProlog
%%BeginResource: procset PageDraw_ops
%%Version: 2.0
%%Copyright: (c) 1993-96 Rajeev V Karunakaran
/PDXDict 100 dict def
PDXDict begin
% width height matrix proc key cache
% definepattern -\> font
/definepattern { %def
  7 dict begin
    /FontDict 9 dict def
    FontDict begin
      /cache exch def
      /key exch def
      /proc exch cvx def
      /mtx exch matrix invertmatrix def
      /height exch def
      /width exch def
      /ctm matrix currentmatrix def
      /ptm matrix identmatrix def
      /str
      (12345678901234567890123456789012)
      def
    end
    /FontBBox [ %def
      0 0 FontDict /width get
      FontDict /height get
    ] def
    /FontMatrix FontDict /mtx get def
    /Encoding StandardEncoding def
    /FontType 3 def
    /BuildChar { %def
      pop begin
      FontDict begin
        width 0 cache { %ifelse
          0 0 width height setcachedevice
        }{ %else
          setcharwidth
        } ifelse
        0 0 moveto width 0 lineto
        width height lineto 0 height lineto
        closepath clip newpath
        gsave proc grestore
      end end
    } def
    FontDict /key get currentdict definefont
  end
} bind def

% dict patternpath -
% dict matrix patternpath -
/patternpath { %def
  dup type /dicttype eq { %ifelse
    begin FontDict /ctm get setmatrix
  }{ %else
    exch begin FontDict /ctm get setmatrix
    concat
  } ifelse
  currentdict setfont
  FontDict begin
    FontMatrix concat
    width 0 dtransform
    round width div exch round width div exch
    0 height dtransform
    round height div exch
    round height div exch
    0 0 transform round exch round exch
    ptm astore setmatrix

    pathbbox
    height div ceiling height mul 4 1 roll
    width div ceiling width mul 4 1 roll
    height div floor height mul 4 1 roll
    width div floor width mul 4 1 roll

    2 index sub height div ceiling cvi exch
    3 index sub width div ceiling cvi exch
    4 2 roll moveto

    FontMatrix ptm invertmatrix pop
    { %repeat
      gsave
        ptm concat
        dup str length idiv { %repeat
          str show
        } repeat
        dup str length mod str exch
        0 exch getinterval show
      grestore
      0 height rmoveto
    } repeat
    pop
  end end
} bind def

% dict patternfill -
% dict matrix patternfill -
/patternfill { %def
  gsave
    clip patternpath
  grestore
  newpath
} bind def

/img { %def
  gsave
  /imgh exch def
  /imgw exch def
  concat
  imgw imgh 8
  [imgw 0 0 imgh neg 0 imgh]
  /colorstr 768 string def
  /colorimage where {
    pop
    { currentfile colorstr readhexstring pop }
    false 3 colorimage
  }{
    /graystr 256 string def
    {
      currentfile colorstr readhexstring pop
      length 3 idiv
      dup 1 sub 0 1 3 -1 roll
      {
        graystr exch
        colorstr 1 index 3 mul get 30 mul
        colorstr 2 index 3 mul 1 add get 59 mul
        colorstr 3 index 3 mul 2 add get 11 mul
        add add 100 idiv
        put
      } for
      graystr 0 3 -1 roll getinterval
    } image
  } ifelse
  grestore
} bind def

/arrowhead {
  gsave
    [] 0 setdash
    strokeC strokeM strokeY strokeK setcmykcolor
    2 copy moveto
    4 2 roll exch 4 -1 roll exch
    sub 3 1 roll sub
    exch atan rotate dup scale
    arrowtype
    dup 0 eq {
      -1 2 rlineto 7 -2 rlineto -7 -2 rlineto
      closepath fill
    } if
    dup 1 eq {
      0 3 rlineto 9 -3 rlineto -9 -3 rlineto
      closepath fill
    } if
    dup 2 eq {
      currentpoint -6 -6 rmoveto lineto -6 6 rlineto
      2 setlinewidth stroke
    } if
    pop
  grestore
} bind def

/setcmykcolor where { %ifelse
  pop
}{ %else
  /setcmykcolor {
     /black exch def /yellow exch def
     /magenta exch def /cyan exch def
     cyan black add dup 1 gt { pop 1 } if 1 exch sub
     magenta black add dup 1 gt { pop 1 } if 1 exch sub
     yellow black add dup 1 gt { pop 1 } if 1 exch sub
     setrgbcolor
  } bind def
} ifelse

/RE { %def
  findfont begin
  currentdict dup length dict begin
    { %forall
      1 index /FID ne { def } { pop pop } ifelse
    } forall
    /FontName exch def dup length 0 ne { %if
      /Encoding Encoding 256 array copy def
      0 exch { %forall
        dup type /nametype eq { %ifelse
          Encoding 2 index 2 index put
          pop 1 add
        }{ %else
          exch pop
        } ifelse
      } forall
    } if pop
  currentdict dup end end
  /FontName get exch definefont pop
} bind def

/spacecount { %def
  0 exch
  ( ) { %loop
    search { %ifelse
      pop 3 -1 roll 1 add 3 1 roll
    }{ pop exit } ifelse
  } loop
} bind def

/WinAnsiEncoding [
  39/quotesingle 96/grave 130/quotesinglbase/florin/quotedblbase
  /ellipsis/dagger/daggerdbl/circumflex/perthousand
  /Scaron/guilsinglleft/OE 145/quoteleft/quoteright
  /quotedblleft/quotedblright/bullet/endash/emdash
  /tilde/trademark/scaron/guilsinglright/oe/dotlessi
  159/Ydieresis 164/currency 166/brokenbar 168/dieresis/copyright
  /ordfeminine 172/logicalnot 174/registered/macron/ring
  177/plusminus/twosuperior/threesuperior/acute/mu
  183/periodcentered/cedilla/onesuperior/ordmasculine
  188/onequarter/onehalf/threequarters 192/Agrave/Aacute
  /Acircumflex/Atilde/Adieresis/Aring/AE/Ccedilla
  /Egrave/Eacute/Ecircumflex/Edieresis/Igrave/Iacute
  /Icircumflex/Idieresis/Eth/Ntilde/Ograve/Oacute
  /Ocircumflex/Otilde/Odieresis/multiply/Oslash
  /Ugrave/Uacute/Ucircumflex/Udieresis/Yacute/Thorn
  /germandbls/agrave/aacute/acircumflex/atilde/adieresis
  /aring/ae/ccedilla/egrave/eacute/ecircumflex
  /edieresis/igrave/iacute/icircumflex/idieresis
  /eth/ntilde/ograve/oacute/ocircumflex/otilde
  /odieresis/divide/oslash/ugrave/uacute/ucircumflex
  /udieresis/yacute/thorn/ydieresis
] def

/patarray [
/leftdiagonal /rightdiagonal /crossdiagonal /horizontal
/vertical /crosshatch /fishscale /wave /brick
] def
/arrowtype 0 def
/fillC 0 def /fillM 0 def /fillY 0 def /fillK 0 def
/strokeC 0 def /strokeM 0 def /strokeY 0 def /strokeK 1 def
/pattern -1 def
/mat matrix def
/c /curveto load def
/C /curveto load def
/e { gsave concat 0 0 moveto } bind def
/F {
  pattern -1 eq { %ifelse
    fillC fillM fillY fillK setcmykcolor fill
  }{ %else
    gsave fillC fillM fillY fillK setcmykcolor fill grestore
    0 0 0 1 setcmykcolor
    patarray pattern get findfont patternfill
  } ifelse
} bind def
/f { closepath F } bind def
/K { /strokeK exch def /strokeY exch def
     /strokeM exch def /strokeC exch def } bind def
/k { /fillK exch def /fillY exch def
     /fillM exch def /fillC exch def } bind def
/L /lineto load def
/m /moveto load def
/n /newpath load def
/N /newpath load def
/S { strokeC strokeM strokeY strokeK setcmykcolor stroke } bind def
/s { closepath S } bind def
/Tx { fillC fillM fillY fillK setcmykcolor show
      0 leading neg translate 0 0 moveto } bind def
/t { %def
  fillC fillM fillY fillK setcmykcolor
  align dup 0 eq { %ifelse
    pop show
  }{ %else
    dup 1 eq { %ifelse
      pop dup stringwidth pop 2 div neg 0 rmoveto show
    }{ %else
      dup 2 eq { %ifelse
        pop dup stringwidth pop neg 0 rmoveto show
      }{ %else
        pop
        dup stringwidth pop jwidth exch sub
        1 index spacecount
        dup 0 eq { %ifelse
          pop pop show
        }{ %else
          div 0 8#040 4 -1 roll widthshow
        } ifelse
      } ifelse
    } ifelse
  } ifelse
  0 leading neg translate 0 0 moveto
} bind def
/T { grestore } bind def
/TX { pop } bind def
/tbx { pop exch pop sub /jwidth exch def } def
/u {} def
/U {} def
/w /setlinewidth load def
/d /setdash load def
/B { gsave F grestore S } bind def
/b { closepath B } bind def
/z { /align exch def pop /leading exch def exch findfont
     exch scalefont setfont } bind def
/Pat { /pattern exch def } bind def
/At { /arrowtype exch def } bind def
/Ln {
  mat currentmatrix pop
    concat
    /y1 exch def /x1 exch def /y2 exch def /x2 exch def
    dup 2 mod 1 eq { currentlinewidth x2 y2 x1 y1 arrowhead } if
    2 idiv 1 eq { currentlinewidth x1 y1 x2 y2 arrowhead } if
    x1 y1 moveto x2 y2 lineto
  mat setmatrix
} bind def
/Ar {
  mat currentmatrix pop
    concat translate scale 0 0 1 5 -2 roll arc
  mat setmatrix
} bind def
/Pi {
  mat currentmatrix pop
    concat translate scale
    0 0 moveto 0 0 1 5 -2 roll arc closepath
  mat setmatrix
} bind def
/Bx {
  mat currentmatrix pop
    concat /y1 exch def /x1 exch def /y2 exch def /x2 exch def
    x1 y1 moveto x1 y2 lineto x2 y2 lineto x2 y1 lineto
  mat setmatrix
} bind def
/Ov {
  mat currentmatrix pop
    concat translate scale 0 0 1 0 360 arc
  mat setmatrix
} bind def
end
%%EndResource
%%EndProlog
%%BeginSetup
%PDX g 18 18 0 0
%%IncludeFont: ArialMT
PDXDict begin
/_PDX_savepage save def

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  7.5 0 moveto 15 7.5 lineto
  0 7.5 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/rightdiagonal true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  7.5 0 moveto 0 7.5 lineto
  15 7.5 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/leftdiagonal true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  0 7.5 moveto 15 7.5 lineto
  2 setlinewidth stroke
} bind
/horizontal true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  7.5 0 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/vertical true definepattern pop

15 15 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  0 7.5 moveto 15 7.5 lineto
  7.5 0 moveto 7.5 15 lineto
  2 setlinewidth stroke
} bind
/crosshatch true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 setlinecap
  0 7.5 moveto 30 7.5 lineto
  0 22.5 moveto 30 22.5 lineto
  7.5 0 moveto 7.5 7.5 lineto
  7.5 22.5 moveto 7.5 30 lineto
  22.5 7.5 moveto 22.5 22.5 lineto
  1 setlinewidth stroke
} bind
/brick true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 2 scale
  2 setlinecap
  7.5 0 moveto 15 7.5 lineto
  0 7.5 moveto 7.5 15 lineto
  7.5 0 moveto 0 7.5 lineto
  15 7.5 moveto 7.5 15 lineto
  0.5 setlinewidth stroke
} bind
/crossdiagonal true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  2 2 scale
  1 setlinecap
  0 7.5 moveto 0 15 7.5 270 360 arc
  7.5 15 moveto 15 15 7.5 180 270 arc
  0 7.5 moveto 7.5 7.5 7.5 180 360 arc
  0.5 setlinewidth stroke
} bind
/fishscale true definepattern pop

30 30 [300 72 div 0 0 300 72 div 0 0]
{ %definepattern
  1 setlinecap 0.5 setlinewidth
  7.5 0 10.6 135 45 arcn
  22.5 15 10.6 225 315 arc
  stroke
  7.5 15 10.6 135 45 arcn
  22.5 30 10.6 225 315 arc
  stroke
} bind
/wave true definepattern pop

WinAnsiEncoding /_ArialMT /ArialMT RE

0 setlinecap 0 setlinejoin 10 setmiterlimit
1 setlinewidth [] 0 setdash
%%EndSetup
%%Page: 1 1
4.33476 4.33474 53.7854 328.375 [1 0 0 1 384.6 160.2] Ov
b
438.581 493.242 m
474.581 466.242 L
474.581 457.242 L
438.581 484.242 L
438.581 493.242 L
1 Pat
s
438.8 486 m
438.8 479.2 L
446 479.2 L
446 474 L
465.2 474 L
465.2 478.8 L
471.6 478.8 L
472 485.6 L
-1 Pat
B
333 486 m
297 486 L
288 495 L
288 720 L
423 720 L
423 486 L
387 486 L
1 Pat
B
387 405 m
405 405 L
414 414 L
414 459 L
387 459 L
B
189 36 m
189 108 L
477 108 L
477 189 L
414 189 L
414 270 L
432 270 L
432 207 L
477 207 L
477 270 L
495 270 L
495 486 L
423 486 L
423 522 L
477 612 L
477 621 L
504 621 L
504 675 L
513 675 L
513 162 L
513 36 L
B
225 162 459 117 [1 0 0 1 0 9] Bx
-1 Pat
b
270 189 m
234 189 L
234 207 L
270 207 L
270 270 L
288 270 L
288 189 L
270 189 L
1 Pat
b
0 243 162 243 117 [1 0 0 1 0 9] Ln
S
0 261 162 261 117 [1 0 0 1 0 9] Ln
S
0 288 162 288 117 [1 0 0 1 -9 9] Ln
S
0 306 162 306 117 [1 0 0 1 -9 9] Ln
S
0 324 162 324 117 [1 0 0 1 -9 9] Ln
S
0 333 162 333 117 [1 0 0 1 0 9] Ln
S
0 351 117 351 162 [1 0 0 1 0 9] Ln
S
0 387 162 387 117 [1 0 0 1 0 9] Ln
S
0 405 162 405 117 [1 0 0 1 0 9] Ln
S
0 423 162 423 117 [1 0 0 1 0 9] Ln
S
0 441 162 441 117 [1 0 0 1 0 9] Ln
S
486 90 198 54 [1 0 0 1 9 0] Bx
-1 Pat
b
324 36 m
324 126 L
387 126 L
387 81 L
387 36 L
B
405 261 279 180 [1 0 0 1 9 9] Bx
b
0 324 261 324 180 [1 0 0 1 9 9] Ln
S
0 360 261 360 180 [1 0 0 1 18 9] Ln
S
0 342 207 324 207 [1 0 0 1 9 9] Ln
S
0 342 216 342 207 [1 0 0 1 9 9] Ln
S
0 351 216 342 216 [1 0 0 1 9 9] Ln
S
0 351 207 351 216 [1 0 0 1 9 9] Ln
S
0 369 207 351 207 [1 0 0 1 9 9] Ln
S
0 216 81 216 45 [1 0 0 1 9 9] Ln
S
0 234 81 234 45 [1 0 0 1 9 9] Ln
S
0 243 81 243 45 [1 0 0 1 9 9] Ln
S
0 441 81 441 45 [1 0 0 1 9 9] Ln
S
0 450 81 450 45 [1 0 0 1 9 9] Ln
S
207 270 m
207 270 207 297 207 315 C
288 315 396 315 468 315 C
477 279 459 297 423 297 C
414 288 408.089 272.071 396 270 C
379.236 267.128 370.931 293.356 360 297 C
324 297 279 297 252 297 C
239.469 293.529 225 279 207 270 c
b
207 315 m
225 333 L
459 333 L
468 315 L
S
0 261 261 198 261 [1 0 0 1 9 9] Ln
S
261 270 m
274.115 287.294 280.277 297 288 297 C
297 297 306 297 315 297 C
322.723 297 328.885 287.294 342 270 C
S
459 288 423 207 [1 0 0 1 9 9] Bx
b
468 243 459 225 [1 0 0 1 9 9] Bx
b
378 333 306 324 [1 0 0 1 18 9] Bx
b
378 639 324 333 [1 0 0 1 9 9] Bx
b
333 405 m
306 405 L
297 414 L
297 423 L
315 423 L
315 423 L
315 423 L
315 441 L
297 441 L
297 459 L
315 459 L
333 459 L
1 Pat
B
378 639 324 612 [1 0 0 1 9 9] Bx
-1 Pat
b
333 432 m
387 432 L
387 450 L
369 450 L
369 621 L
351 621 L
351 450 L
333 450 L
333 432 L
b
437.122 384.829 m
473.122 357.829 L
473.122 348.829 L
437.122 375.829 L
437.122 384.829 L
1 Pat
s
4.33476 4.33474 53.7854 328.375 [1 0 0 1 383.1 51.83] Ov
-1 Pat
b
4.33476 4.33474 53.7854 328.375 [1 0 0 1 419.9 24.66] Ov
b
437.543 411.752 m
473.543 384.752 L
473.543 375.752 L
437.543 402.752 L
437.543 411.752 L
1 Pat
s
4.33476 4.33474 53.7854 328.375 [1 0 0 1 383.5 78.75] Ov
-1 Pat
b
4.33476 4.33474 53.7854 328.375 [1 0 0 1 420.4 51.59] Ov
b
437.16 441.319 m
473.16 414.319 L
473.16 405.319 L
437.16 432.319 L
437.16 441.319 L
1 Pat
s
4.33476 4.33474 53.7854 328.375 [1 0 0 1 383.2 108.3] Ov
-1 Pat
b
4.33476 4.33474 53.7854 328.375 [1 0 0 1 420 81.15] Ov
b
437.581 468.242 m
473.581 441.242 L
473.581 432.242 L
437.581 459.242 L
437.581 468.242 L
1 Pat
s
4.33476 4.33474 53.7854 328.375 [1 0 0 1 383.6 135.2] Ov
-1 Pat
b
4.33476 4.33474 53.7854 328.375 [1 0 0 1 420.4 108.1] Ov
b
451.456 507.385 442.6 342.6 [1 0 0 1 9 9] Bx
b
323.909 342.273 277.608 332.663 [1 0 0 1 9 9] Bx
b
387.073 341.663 m
387.073 351.273 L
441.2 351.2 L
441.237 356.515 L
451.72 356.515 L
451.6 351.6 L
460.4 351.6 L
460.456 356.515 L
473.56 356.515 L
473.56 341.663 L
394.935 341.663 L
B
0 437.8 347.4 437.8 332.6 [1 0 0 1 9 9] Ln
S
0 455.4 347 455.4 332.6 [1 0 0 1 9 9] Ln
S
342 720 m
342 684 L
351 675 L
369 675 L
378 684 L
378 720 L
B
378 720 324 711 [1 0 0 1 9 9] Bx
b
330 747 m
330 729 L
390 729 L
390 747 L
390 747 L
390 747 L
B
0 366 738 366 720 [1 0 0 1 9 9] Ln
S
0 336 738 336 720 [1 0 0 1 9 9] Ln
S
330 747 m
333 750 342 750 345 747 C
B
345 747 m
348 750 372 750 375 747 C
B
375 747 m
378 750 387 750 390 747 C
B
0 374.375 740.375 328.375 740.375 [1 0 0 1 9 9] Ln
S
0 369 678 333 675 [1 0 0 1 9 9] Ln
S
0 369 681 333 678 [1 0 0 1 9 12] Ln
S
0 369 690 333 687 [1 0 0 1 9 9] Ln
S
0 369 696 333 693 [1 0 0 1 9 9] Ln
S
0 369 702 333 699 [1 0 0 1 9 9] Ln
S
0 369 708 333 705 [1 0 0 1 9 9] Ln
S
387 522 m
423 522 L
477 612 L
477 621 L
504 621 L
504 675 L
441 675 L
441 621 L
459 621 L
459 612 L
423 549 L
387 549 L
387 522 L
b
504 738 414 666 [1 0 0 1 9 9] Bx
b
288 522 m
261 522 L
261 540 L
234 540 L
234 522 L
207 522 L
243 567 L
279 567 L
279 576 L
288 576 L
0 Pat
B
126 522 m
180 522 L
216 567 L
180 567 L
180 549 L
171 549 L
171 540 L
126 540 L
126 522 L
B
288 621 m
279 621 L
279 630 L
180 630 L
180 639 L
180 648 L
126 648 L
126 666 L
288 666 L
B
288 576 m
315 576 L
324 576 L
324 585 L
333 585 L
333 612 L
324 612 L
324 621 L
288 621 L
-1 Pat
B
162 576 99.2857 557.857 [1 0 0 1 9 9] Bx
5 Pat
b
162 621 99 603 [1 0 0 1 9 9] Bx
b
324 603 81 576 [1 0 0 1 9 9] Bx
-1 Pat
b
171 549 m
63 549 L
54 567 L
54 630 L
63 648 L
180 648 L
180 630 L
171 630 L
171 639 L
70.25 639.25 L
63.25 625.25 L
63.25 571.25 L
70.25 558.25 L
108 558 L
171 558 L
B
4.33476 4.33474 53.7854 328.375 [1 0 0 1 421.4 133.1] Ov
b
1 1 1 0 k
/_ArialMT 16 16 0 0 z
[0 1 -1 0 141 30] e
76.465 -3.6 0 14.896 tbx
(Drive shaft) t
T
1 At
2 339 45 147 39 [1 0 0 1 0 0] Ln
S
[0 1 -1 0 141 153] e
35.569 -3.6 0 14.896 tbx
(Gear) t
T
1 At
2 234 150 147 156 [1 0 0 1 0 0] Ln
S
[0 1 -1 0 156 216] e
70.241 -3.6 0 14.896 tbx
(Face cam) t
T
1 At
2 288 279 162 225 [1 0 0 1 0 0] Ln
S
[0 1 -1 0 210 396] e
51.569 -3.6 0 14.896 tbx
(Control) t
T
[0 1 -1 0 231 399] e
46.241 -3.6 0 14.896 tbx
(sleeve) t
T
1 At
2 306 444 243 414 [1 0 0 1 0 0] Ln
S
[0 1 -1 0 78 396] e
95.153 -3.6 0 14.896 tbx
(Magnet valve) t
T
1 At
2 75 543 75 501 [1 0 0 1 0 0] Ln
S
[0 1 -1 0 198 696] e
55.137 -3.6 0 14.896 tbx
(Plunger) t
T
1 At
2 342 609 201 702 [1 0 0 1 0 0] Ln
S
[0 1 -1 0 237 708] e
55.137 -3.6 0 14.896 tbx
(Plunger) t
T
[0 1 -1 0 255 708] e
40.897 -3.6 0 14.896 tbx
(barrel) t
T
1 At
2 312 681 258 705 [1 0 0 1 0 0] Ln
S
483 660 459 675 [1 0 0 1 0 0] Bx
0 0 0 0 k
b
1 1 1 0 k
[0 1 -1 0 564 594] e
99.569 -3.6 0 14.896 tbx
(Delivery valve) t
T
1 At
2 489 660 540 636 [1 0 0 1 0 0] Ln
S
[0 1 -1 0 561 432] e
103.153 -3.6 0 14.896 tbx
(Plunger spring) t
T
1 At
1 540 447 483 417 [1 0 0 1 0 0] Ln
S
[0 1 -1 0 555 282] e
66.673 -3.6 0 14.896 tbx
(Cam disk) t
T
1 At
2 471 324 534 315 [1 0 0 1 0 0] Ln
S
[0 1 -1 0 552 183] e
41.777 -3.6 0 14.896 tbx
(Roller) t
T
1 At
2 459 234 537 207 [1 0 0 1 0 0] Ln
S
[0 1 -1 0 552 42] e
80.929 -3.6 0 14.896 tbx
(Feed pump) t
T
1 At
2 489 72 531 57 [1 0 0 1 0 0] Ln
S
/_ArialMT 22 22 0 0 z
[0 0.8585 -1.551 0 73.96 36.32] e
358.249 -4.95 0 20.482 tbx
(Cross sectional view of the VE pump) t
T
2 w
0 81 342 81 33 [1 0 0 1 0 3] Ln
S
210 630 198 567 [1 0 0 1 0 0] Bx
0 0 0 0 k
1 w
b
0 171 567 171 558 [1 0 0 1 0 0] Ln
S
357 378 m
357 390 L
357 396 L
354 396 L
360 408 L
366 396 L
363 396 L
363 378 L
363 369 L
366 369 L
360 357 L
354 369 L
357 369 L
357 378 L
s
%%PageTrailer
_PDX_savepage restore
%%Trailer
end
% Before sending this file to a PostScript printer,
% remove % character from next line.
% showpage
%%EOF
